<?php

namespace Coinfide;

class CoinfideException extends \Exception
{

}
